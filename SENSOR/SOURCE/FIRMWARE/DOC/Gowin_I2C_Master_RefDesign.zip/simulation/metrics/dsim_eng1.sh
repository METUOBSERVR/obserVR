#!/bin/bash
# dsim_eng1.sh
# Bash script to simulate design with Metrics DSim on eng-1

# Set up environment
WAVE_FILE=waves.mxd
WAVE_LIST=wave.list
set -e

# Compile standard libraries
dlib map -lib ieee ${STD_LIBS}/ieee93

# Compile and Simulate design, and dump waveform
dsim -top work.i2c_tb -F filelist.txt +acc+b -waves $WAVE_FILE -wave-scope-specs $WAVE_LIST
