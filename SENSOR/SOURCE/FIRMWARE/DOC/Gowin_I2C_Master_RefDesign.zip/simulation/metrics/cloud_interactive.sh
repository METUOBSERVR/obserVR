#!/bin/bash
# cloud_interactive.sh
# Bash script to simulate design with Metrics DSim Cloud

# Set up environment
WAVE_FILE=waves.mxd
WAVE_LIST=wave.list
set -e

# Compile and Simulate design, and dump waveform
mdc dsim -a "-top work.i2c_tb -F filelist.txt +acc+b -waves $WAVE_FILE -wave-scope-specs $WAVE_LIST"
