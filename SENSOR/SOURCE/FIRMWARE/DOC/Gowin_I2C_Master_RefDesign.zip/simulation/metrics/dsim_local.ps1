# dsim_local.ps1
# PowerShell script to simulate design with Metrics DSim on local machine

# Set up environment
$WAVE_FILE = "waves.mxd"
$WAVE_LIST = "wave.list"

# Compile and Simulate design, and dump waveform
dsim -top work.i2c_tb -F filelist.txt +acc+b -waves $WAVE_FILE -wave-scope-specs $WAVE_LIST
