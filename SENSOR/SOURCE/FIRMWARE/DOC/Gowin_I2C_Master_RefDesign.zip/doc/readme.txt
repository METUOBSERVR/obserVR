﻿______________________________________________________________________
         GOWIN I2C MASTER IP参考设计阅读指南
----------------------------------------------------------------------
目标器件：GW1N-LV4LQ144C6/I5
----------------------------------------------------------------------
文件列表
----------------------------------------------------------------------
.
|-- doc
|   `-- readme.txt                          -->  自述文件
|-- tb
|   `-- i2c_tb.v                            -->  GOWIN I2C参考设计仿真TestBench文件
|-- simulation
|   |-- Modelsim
|   |   `-- cmd.do			                 -->	 Modelsim仿真脚本
│   └── mdc
│       `-- filelist.txt                    -->	 要编译的文件列表
│       `-- wave.list                       -->  波形储存列表
|-- simlib
|   |-- gw1n
|   |   `-- prim_sim.v                      -->  GOWIN GW1N系列FPGA仿真库文件
|   |-- gw2a
|       `-- prim_sim.v                      -->  GOWIN GW2A系列FPGA仿真库文件
|-- project
|   |-- gw_i2c_master
|   |   `-- gw_i2c_master.gprj              -->  GOWIN I2C MASTER IP参考设计工程
|   |   |-- impl
|   |   |-- src
|   |   |   |-- gowin_rpll                  -->  参考设计IP文件夹
|   |   |   |-- i2c_master                  -->  参考设计IP文件夹
|   |   |   `-- gw_i2c_master.sdc           -->  参考设计工程文件
|   |   |   `-- gw_i2c_master.v             -->  参考设计工程文件
|   |   |   `-- i2c_master.cst              -->  参考设计工程文件
|   |   |   `-- master_sram_iic.v           -->  参考设计工程文件
|   |   |   `-- gw_i2c_master.rao           -->  参考设计工程文件
|   |-- gw_i2c_slave
|   |   `-- gw_i2c_slave.gprj               -->  GOWIN I2C SLAVE参考设计工程
|   |   |-- impl
|   |   |-- src
|   |   |   |-- gowin_rpll                  -->  参考设计IP文件夹
|   |   |   `-- gw_i2c_slave.sdc            -->  参考设计工程文件
|   |   |   `-- gw_i2c_slave.v              -->  参考设计工程文件
|   |   |   `-- i2c_slave.cst               -->  参考设计工程文件
|   |   |   `-- i2c_slave_defines.v         -->  参考设计工程文件
|   |   |   `-- I2C_SLAVE_TOP.v             -->  参考设计工程文件
|   |   |   `-- rom_init.v                  -->  参考设计工程文件

---------------------------------------------------------------------------------------------------------------
如何在云源软件里打开工程：
---------------------------------------------------------------------------------------------------------------
1. 解压已压缩的设计文件。
2. 启动云源软件并选择“File -> Open”。
3. 在已打开的“Open File”窗口中进入对应工程所在路径，选择工程文件“gw_i2c_master.gprj”。
4. 点击“打开”，则工程即可加载。

---------------------------------------------------------------------------------------------------------------
如何在云源软件中运行综合，布局布线及时序分析：
---------------------------------------------------------------------------------------------------------------
1. 点击云源软件界面中Process面板中的Process选项卡，双击Synthsize(GowinSynthesis)，这将使设计运行综合。
2. 点击”Project -> Configuration -> Place & Route”以设置生成Post-Place文件及Post-PnR文件等。
3. 点击云源软件界面中Process面板中的Process选项卡，双击Place & Route，这将使设计运行映射及布局布线。
4. 当布局布线完成时，用户可以双击Timing Analysis Report得到时序分析结果。

----------------------------------------------------------------------------------------------------------------
如何运行工程仿真：
----------------------------------------------------------------------------------------------------------------
注意：您需要安装 DSim Cloud CLI，并登录您的 DSim Cloud 帐户
      - 有关更多信息，请参见此处： https://metrics.ca/gowin-customers/

1. 打开一个终端窗口, cd 至目录“Gowin_I2C_Master_RefDesign”。
2. 输入“mdc initialize”创建DSim Cloud Workspace (工作区)
3. 输入“cd simulation/mdc”导航到仿真目录。
4. 输入“mdc dsim -a '-top work.i2c_tb +acc+b -F filelist.txt -waves waves.mxd -wave-scope-specs wave.list'” 对工程进行仿真。
5. 查看结果：
   * 下载仿真记录文件 - 输入“mdc download dsim.log”
   * 波形 - 输入“mdc view wave waves.mxd”查看mxd波形。
----------------------------------------------------------------------------------------------------------------


________________________________________________________________________
	  GOWIN I2C MASTER IP Design Example Readme
------------------------------------------------------------------------
Object device: GW1N-LV4LQ144C6/I5
---------------------------------------------------------------------------
File List:
---------------------------------------------------------------------------
.
|-- doc
|   `-- readme.txt                          -->  Read Me file (this file)
|-- tb
|   `-- i2c_tb.v                            -->  TestBench file for the GOWIN I2C Ref design
|-- simulation
|   |-- Modelsim
|   |   `-- cmd.do			                 -->	 Modelsim simulation script
│   └── mdc
│       `-- filelist.txt                    -->	 List of files to compile
│       `-- wave.list                       -->  List of signals for waveform dumping
|-- simlib
|   |-- gw1n
|   |   `-- prim_sim.v                      -->  GOWIN GW1N FPGA simulation library file
|   |-- gw2a
|       `-- prim_sim.v                      -->  GOWIN GW2A FPGA simulation library file
|-- project
|   |-- gw_i2c_master
|   |   `-- gw_i2c_master.gprj              -->  Project for GOWIN I2C MASTER IP Design Example
|   |   |-- impl
|   |   |-- src
|   |   |   |-- gowin_rpll                  -->  IP File folder for Gowin Project
|   |   |   |-- i2c_master                  -->  IP File folder for Gowin Project
|   |   |   `-- gw_i2c_master.sdc           -->  File for Gowin Project
|   |   |   `-- gw_i2c_master.v             -->  File for Gowin Project
|   |   |   `-- i2c_master.cst              -->  File for Gowin Project
|   |   |   `-- master_sram_iic.v           -->  File for Gowin Project
|   |   |   `-- gw_i2c_master.rao           -->  File for Gowin Project
|   |-- gw_i2c_slave
|   |   `-- gw_i2c_slave.gprj               -->  Project for  GOWIN I2C SLAVE Design Example
|   |   |-- impl
|   |   |-- src
|   |   |   |-- gowin_rpll                  -->  IP File folder for Gowin Project
|   |   |   `-- gw_i2c_slave.sdc            -->  File for Gowin Project
|   |   |   `-- gw_i2c_slave.v              -->  File for Gowin Project
|   |   |   `-- i2c_slave.cst               -->  File for Gowin Project
|   |   |   `-- i2c_slave_defines.v         -->  File for Gowin Project
|   |   |   `-- I2C_SLAVE_TOP.v             -->  File for Gowin Project
|   |   |   `-- rom_init.v                  -->  File for Gowin Project


---------------------------------------------------------------------------------------------------------------
HOW TO OPEN A PROJECT IN GOWIN EDA:
---------------------------------------------------------------------------------------------------------------
1. Unzip the compressed design files.
2. Start the GowinYunYuan and select "File -> Open"
3. In the Open File dialog, enter the Project location, select the project "gw_i2c_master.gprj".
4. Click "Open". Then the project could be loaded.

---------------------------------------------------------------------------------------------------------------
HOW TO RUN SYNTHESIZE, PLACE&ROUTE AND TIMING ANALYSIS IN GOWIN EDA:
---------------------------------------------------------------------------------------------------------------
1. Click the Process tab in the process panel of the GOWIN EDA dashboard.
   Double click on Synthsize(GowinSynthesis). This will bring the design through synthesis.
2. Click on "Project -> Configuration -> Place & Route" to configurate the generation of the Post-Place File
   and SDF File,etc.
3. Click the Process tab in the process panel of the GOWIN EDA dashboard.
   Double click on Place & Route. This will bring the design through mapping, place and route.
4. Once Place & Route is done, user can double click on Timing Analysis Report to get
   the timing analysis result.

----------------------------------------------------------------------------------------------------------------
HOW TO RUN SIMULATION
----------------------------------------------------------------------------------------------------------------
You need to have a DSim Cloud account:
https://www.metrics.ca/

To run the simulation in Metrics DSim Desktop, go to:
https://help.metrics.ca/support/solutions/articles/154000151811-tutorial-dsim-desktop-for-gowin

To run the simulation in Metrics DSim Cloud, go to:
https://help.metrics.ca/support/solutions/articles/154000141170-tutorial-dsim-cloud-walkthrough-for-gowin-customers